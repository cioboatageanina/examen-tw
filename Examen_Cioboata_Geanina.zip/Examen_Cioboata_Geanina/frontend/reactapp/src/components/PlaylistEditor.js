import { useEffect, useState } from 'react';
import {useSelector, shallowEqual, useDispatch} from 'react-redux';

import {DataTable} from 'primereact/datatable'
import { Column } from 'primereact/column'
import {Button} from 'primereact/button'
import {Dialog} from 'primereact/dialog'
import {InputText} from 'primereact/inputtext'

import {playlistActions} from '../actions'
const playlistListSelector = state => state.playlist.playlistList

function PlaylistEditor() {
  const [isDialogShown, setIsDialogShown] = useState(false)
  const [description, setDescription] = useState('')
  const [date, setDate] = useState('')
  const [isNewPlaylist, setIsNewPlaylist] = useState(true)
  const [selected, setSelected] = useState(null)
    const playlistList = useSelector(playlistListSelector, shallowEqual)

    const dispatch = useDispatch()

    useEffect(() => {
        dispatch(playlistActions.getPlaylists())
    }, [dispatch])

    const addNew = () =>{
      setIsDialogShown(true)
      setDescription('')
      setDate('')
      setSelected(null)
      setIsNewPlaylist()
    }

    const hideDialog = () =>{
      setIsDialogShown(false)
    }

    const updatePlaylist = () => {
      if(isNewPlaylist) {
        dispatch(playlistActions.addPlaylist({description, date}))
      }
      else {
        dispatch(playlistActions.updatePlaylist(selected, {description, date}))
      }
      setIsDialogShown(false)
      setDescription('')
      setDate('')
      setSelected(null)
    }

    const tableFooter = (
      <div>
        <Button label='Add' icon='pi pi-plus' onClick={addNew}/>
      </div>
    )

    const addDialogFooter = (
      <div>
      <Button label='Save' icon='pi pi-save' onClick={updatePlaylist}/>
    </div>
    )


    const deletePlaylist = (rowData) => {
      dispatch(playlistActions.deletePlaylist(rowData.id))
    }

    
    const editPlaylist = (rowData) => {
      setSelected(rowData.id)
      setDescription(rowData.description)
      setDate(rowData.date)
      setIsDialogShown(true)
      setIsNewPlaylist(false)
    }

    const opsColumn = (rowData) => {
      <div>
      <Button  icon='pi pi-times' className='p-button-danger' onClick={() => deletePlaylist(rowData)}/>
      <Button  icon='pi pi-pencil' className='p-button-warning' onClick={() => editPlaylist(rowData)}/>
    </div>
    }

    return (
      <div >
        <DataTable value={playlistList} footer={tableFooter}>
          <Column header="Description" field='description'/>
          <Column header="Date" field='date'/>
          <Column body={opsColumn} />

        </DataTable>
        {
          isDialogShown
          ? (
              <Dialog visible={isDialogShown} onHide={hideDialog} footer={addDialogFooter} header='A playlist'>
                  <InputText onChange={(evt) => setDescription(evt.target.value)} value={description} name='description'
                  placeholder='description'/>
                  <InputText onChange={(evt)=> setDate(evt.target.value)} value={date} name='date' placeholder='date'/>
              </Dialog>
          ) : null
        }
      </div>
    );
  }
  
  export default PlaylistEditor;
  