import PlaylistEditor from "./PlaylistEditor";

function App() {
  return (
    <div >
        <PlaylistEditor />
    </div>
  );
}

export default App;
