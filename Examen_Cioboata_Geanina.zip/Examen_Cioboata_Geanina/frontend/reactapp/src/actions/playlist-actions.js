import { SERVER } from "../config/global"

export const GET_PLAYLISTS = 'GET_PLAYLISTS'
export const ADD_PLAYLIST = 'UPDATE_PLAYLIST'
export const UPDATE_PLAYLIST = 'GET_PLAYLISTS'
export const DELETE_PLAYLIST = 'DELETE_PLAYLIST'

export function getPlaylists() {
    return {
        type: GET_PLAYLISTS, 
        payload: async () => {
            const response = await fetch(`${SERVER}/playlists`)
            const data = await response.json()
            return data
        }
    }
}

export function addPlaylist(playlist) {
    return {
        type: ADD_PLAYLIST, 
        payload: async () => {
            const response = await fetch(`${SERVER}/playlists`, {
                method: 'post',
                headers:{
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(playlist)
            })
            response = await fetch(`${SERVER}/playlists`)
            const data = await response.json()
            return data
        }
    }
}


export function updatePlaylist(id, playlist) {
    return {
        type: UPDATE_PLAYLIST, 
        payload: async () => {
            const response = await fetch(`${SERVER}/playlists/${id}`, {
                method: 'put',
                headers:{
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(playlist)
            })
            response = await fetch(`${SERVER}/playlists`)
            const data = await response.json()
            return data
        }
    }
}


export function deletePlaylist(id) {
    return {
        type: DELETE_PLAYLIST, 
        payload: async () => {
            const response = await fetch(`${SERVER}/playlists/${id}`, {
                method: 'delete'
            })
            response = await fetch(`${SERVER}/playlists`)
            const data = await response.json()
            return data
        }
    }
}