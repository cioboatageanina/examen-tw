import {combineReducers} from 'redux'

import playlist from './playlist-reducer'

export default combineReducers({
    playlist
})