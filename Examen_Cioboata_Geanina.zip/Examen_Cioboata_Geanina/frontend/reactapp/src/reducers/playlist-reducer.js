import { GET_PLAYLISTS } from "../actions/playlist-actions"

const INITIAL_STATE = {
    playlistList: [],
    error:null,
    fetching: false,
    fetched: false
}

export default function reducer(state=INITIAL_STATE, action){
    switch (action.type){
        case 'GET_PLAYLISTS_PENDING':
        case 'ADD_PLAYLISTS_PENDING':
        case 'UPDATE_PLAYLISTS_PENDING':
        case 'DELETE_PLAYLISTS_PENDING':    
            return {...state, error: null, fetching: true, fetched: false}
        case 'GET_PLAYLISTS_FULFILLED':
        case 'ADD_PLAYLISTS_FULFILLED':
        case 'UPDATE_PLAYLISTS_FULFILLED':
        case 'DELETE_PLAYLISTS_FULFILLED':
            return {...state, playlistList: action.payload, fetching: false, fetched: true}
        case 'GET_PLAYLISTS_REJECTED':
        case 'ADD_PLAYLISTS_REJECTED':
        case 'UPDATE_PLAYLISTS_REJECTED':
        case 'DELETE_PLAYLISTS_REJECTED':
            return {...state, error: action.payload, fetching: false, fetched: false}
        default:
            return state
    }
}