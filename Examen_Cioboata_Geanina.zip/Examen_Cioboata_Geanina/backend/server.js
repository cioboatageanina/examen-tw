const express = require('express')
const bodyParser = require('body-parser')
const Sequelize = require('sequelize')
const Op = Sequelize.Op
const cors = require('cors')
const { DataTypes } = require('sequelize');

const sequelize = new Sequelize({
    dialect: 'sqlite',
    storage: 'sample.db',
    define: {
      timestamps: false
    }
  })
  
  const Playlist = sequelize.define('playlist', {
    id:{
        primaryKey:true,
        allowNull:false,
        type:DataTypes.INTEGER,
        autoIncrement:true
    },
    description: {
        type: DataTypes.STRING,
        allowNull: false,
        validate:{
            len: [3, 50]
        }
    }    ,
    date:{
        type:DataTypes.DATEONLY
    }
  })
  
  const Song = sequelize.define('song', {
    id:{
        primaryKey:true,
        allowNull:false,
        type:DataTypes.INTEGER,
        autoIncrement:true
    },
    title: {
        type: DataTypes.STRING,
        allowNull: false,
        validate:{
            len: [5, 20]
        }
    }    ,
    url:{
        type:DataTypes.STRING,
        validate:{
            isUrl: true
        }
    },
    style:{
        type:DataTypes.ENUM("POP","ALTERNATIVE","ROCK"),
    }
  })
  
  Playlist.hasMany(Song)
  
  const app = express()
  app.use(cors())
  app.use(bodyParser.json())
  
  app.get('/sync', async (req, res) => {
    try {
      await sequelize.sync({ force: true })
      res.status(201).json({ message: 'created' })
    } catch (e) {
      console.warn(e)
      res.status(500).json({ message: 'server error' })
    }
  })
  
  app.get('/playlists', async (req, res) => {
    try {
      const query = {}
      let pageSize = 2
      const allowedFilters = ['description', 'date']
      const filterKeys = Object.keys(req.query).filter(e => allowedFilters.indexOf(e) !== -1)
      if (filterKeys.length > 0) {
        query.where = {}
        for (const key of filterKeys) {
          query.where[key] = {
            [Op.like]: `%${req.query[key]}%`
          }
        }
      }
  
      const sortField = req.query.sortField
      let sortOrder = 'ASC'
      if (req.query.sortOrder && req.query.sortOrder === '-1') {
        sortOrder = 'DESC'
      }
  
      if (req.query.pageSize) {
        pageSize = parseInt(req.query.pageSize)
      }
  
      if (sortField) {
        query.order = [[sortField, sortOrder]]
      }
  
      if (!isNaN(parseInt(req.query.page))) {
        query.limit = pageSize
        query.offset = pageSize * parseInt(req.query.page)
      }
  
      const records = await Playlist.findAll(query)
      const count = await Playlist.count()
      res.status(200).json({ records, count })
    } catch (e) {
      console.warn(e)
      res.status(500).json({ message: 'server error' })
    }
  })
  
  app.post('/playlists', async (req, res) => {
    try {
      if (req.query.bulk && req.query.bulk === 'on') {
        await Playlist.bulkCreate(req.body)
        res.status(201).json({ message: 'created' })
      } else {
        await Playlist.create(req.body)
        res.status(201).json({ message: 'created' })
      }
    } catch (e) {
      console.warn(e)
      res.status(500).json({ message: 'server error' })
    }
  })
  
  app.get('/playlists/:id', async (req, res) => {
    try {
      const playlist = await Playlist.findByPk(req.params.id)
      if (playlist) {
        res.status(200).json(playlist)
      } else {
        res.status(404).json({ message: 'not found' })
      }
    } catch (e) {
      console.warn(e)
      res.status(500).json({ message: 'server error' })
    }
  })
  
  app.put('/playlists/:id', async (req, res) => {
    try {
      const playlist = await Playlist.findByPk(req.params.id)
      if (playlist) {
        await playlist.update(req.body, { fields: ['description', 'date'] })
        res.status(202).json({ message: 'accepted' })
      } else {
        res.status(404).json({ message: 'not found' })
      }
    } catch (e) {
      console.warn(e)
      res.status(500).json({ message: 'server error' })
    }
  })
  
  app.delete('/playlists/:id', async (req, res) => {
    try {
      const playlist = await Playlist.findByPk(req.params.id, { include: Song })
      if (playlist) {
        await playlist.destroy()
        res.status(202).json({ message: 'accepted' })
      } else {
        res.status(404).json({ message: 'not found' })
      }
    } catch (e) {
      console.warn(e)
      res.status(500).json({ message: 'server error' })
    }
  })
  
  app.get('/playlists/:pid/songs', async (req, res) => {
    try {
      const playlist = await Playlist.findByPk(req.params.pid)
      if (playlist) {
        const songs = await playlist.getSongs()
  
        res.status(200).json(songs)
      } else {
        res.status(404).json({ message: 'not found' })
      }
    } catch (e) {
      console.warn(e)
      res.status(500).json({ message: 'server error' })
    }
  })
  
  app.get('/playlists/:pid/songs/:sid', async (req, res) => {
    try {
      const playlist = await Playlist.findByPk(req.params.bid)
      if (playlist) {
        const songs = await playlist.getSongs({ where: { id: req.params.sid } })
        res.status(200).json(songs.shift())
      } else {
        res.status(404).json({ message: 'not found' })
      }
    } catch (e) {
      console.warn(e)
      res.status(500).json({ message: 'server error' })
    }
  })
  
  app.post('/playlist/:pid/songs', async (req, res) => {
    try {
      const playlist = await Playlist.findByPk(req.params.pid)
      if (playlist) {
        const song = req.body
        song.playlistId = playlist.id
        console.warn(song)
        await Song.create(song)
        res.status(201).json({ message: 'created' })
      } else {
        res.status(404).json({ message: 'not found' })
      }
    } catch (e) {
      console.warn(e)
      res.status(500).json({ message: 'server error' })
    }
  })
  
  app.put('/playlist/:pid/songs/:sid', async (req, res) => {
    try {
      const playlist = await Playlist.findByPk(req.params.pid)
      if (playlist) {
        const songs = await Playlist.getSongs({ where: { id: req.params.sid } })
        const song = songs.shift()
        if (song) {
          await song.update(req.body)
          res.status(202).json({ message: 'accepted' })
        } else {
          res.status(404).json({ message: 'not found' })
        }
      } else {
        res.status(404).json({ message: 'not found' })
      }
    } catch (e) {
      console.warn(e)
      res.status(500).json({ message: 'server error' })
    }
  })
  
  app.delete('/playlists/:pid/songs/:sid', async (req, res) => {
    try {
      const playlist = await Playlist.findByPk(req.params.bid)
      if (playlist) {
        const songs = await playlist.getSongs({ where: { id: req.params.sid } })
        const song = songs.shift()
        if (song) {
          await song.destroy(req.body)
          res.status(202).json({ message: 'accepted' })
        } else {
          res.status(404).json({ message: 'not found' })
        }
      } else {
        res.status(404).json({ message: 'not found' })
      }
    } catch (e) {
      console.warn(e)
      res.status(500).json({ message: 'server error' })
    }
  })
  
  app.listen(8080)